local OpenUI = Instance.new("ScreenGui") 
local ImageButton = Instance.new("ImageButton") 
local UICorner = Instance.new("UICorner") 
OpenUI.Name = "OpenUI" 
OpenUI.Parent = game.CoreGui 
OpenUI.ZIndexBehavior = Enum.ZIndexBehavior.Sibling 
ImageButton.Parent = OpenUI 
ImageButton.BackgroundColor3 = Color3.fromRGB(5, 6, 7) 
ImageButton.BackgroundTransparency = 0.500 
ImageButton.Position = UDim2.new(0.0235790554, 0, 0.466334164, 0) 
ImageButton.Size = UDim2.new(0, 50, 0, 50) 
ImageButton.Image = "rbxassetid://15613380753" 
ImageButton.Draggable = true 
UICorner.CornerRadius = UDim.new(0, 200) 
UICorner.Parent = ImageButton 
ImageButton.MouseButton1Click:Connect(function() 
  if uihide == false then
	uihide = true
	game.CoreGui.ui.Main:TweenSize(UDim2.new(0, 0, 0, 0),"In","Quad",0.4,true)
else
	uihide = false
	game.CoreGui.ui.Main:TweenSize(UDim2.new(0, 560, 0, 319),"Out","Quad",0.4,true)
		end 
		
end)

uihide = false

local lib = loadstring(game:HttpGet("https://raw.githubusercontent.com/Sidhsksjsjsh/VAPE-UI-MODDED/main/.lua"))()
local wndw = lib:Window("猫脚本--伐木工模拟器")
local T1 = wndw:Tab("主要功能")
local T2 = wndw:Tab("攻击功能")
local T3 = wndw:Tab("其他功能")
local T4 = wndw:Tab("抽蛋功能")

local workspace = game:GetService("Workspace")
local enemy = {}
local items = {}
local egg = {}

lib:AddTable(workspace["Mobs"]["1"],enemy)
lib:AddTable(game:GetService("ReplicatedStorage")["Items"],items)
lib:AddTable(workspace["Eggs"],egg)

T1:Toggle("自动点击",false,function(value)
  _G.click = value
    while wait() do
      if _G.click == false then break end
      game:GetService("ReplicatedStorage")["ClickEvent"]:FireServer("Click")
    end
end)

T1:Toggle("自动领取奖励",false,function(value)
  _G.cr = value
    while wait() do
      if _G.cr == false then break end
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward1")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward2")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward3")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward4")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward5")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward6")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward7")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward8")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward9")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward10")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward11")
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClaimGift"]:FireServer("Reward12")
    end
end)

T1:Toggle("自动重生",false,function(value)
  _G.rbr = value
    while wait() do
      if _G.rbr == false then break end
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["RebirthEvent"]:FireServer()
    end
end)

T3:Dropdown("选择物品",items,function(value)
    _G.tool = value
end)

T3:Button("装备工具",function()
  for array = 1,#game:GetService("ReplicatedStorage")["Items"][_G.tool]:GetChildren() do
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteEvent"]["ClickChangeEvent"]:FireServer(game:GetService("ReplicatedStorage")["Items"][_G.tool][array])
  end
end)

T2:Dropdown("选择敌人",enemy,function(value)
    _G.enmy = value
end)

T2:Toggle("自动攻击",false,function(value)
  _G.atke = value
    while wait() do
      if _G.atke == false then break end
        for i,v in pairs(workspace["Mobs"]["1"][_G.enmy]:GetDescendants()) do
            if v:IsA("ProximityPrompt") then
               fireproximityprompt(v)
            end
       end
    end
end)

T4:Dropdown("选择蛋",egg,function(value)
    _G.ball = value
end)

T4:Toggle("自动抽蛋",false,function(value)
  _G.aht = value
    while wait() do
      if _G.aht == false then break end
      game:GetService("ReplicatedStorage")["GameClient"]["Events"]["RemoteFunction"]["BuyEgg"]:InvokeServer(_G.ball,"Buy1")
    end
end)