local NotificationHolder = loadstring(game:HttpGet("https://raw.githubusercontent.com/BocusLuke/UI/main/STX/Module.Lua"))() 
 local Notification = loadstring(game:HttpGet("https://raw.githubusercontent.com/BocusLuke/UI/main/STX/Client.Lua"))() 

 wait(1) 
 Notification:Notify( 
     {Title = "猫王", Description = "正在加载"}, 
     {OutlineColor = Color3.fromRGB(80, 80, 80),Time = 5, Type = "image"}, 
     {Image = "http://www.roblox.com/asset/?id=4483345998", ImageColor = Color3.fromRGB(255, 84, 84)} 
 ) 
 wait(2) 
 Notification:Notify( 
     {Title = "猫王", Description = "准备好了！"}, 
     {OutlineColor = Color3.fromRGB(80, 80, 80),Time = 5, Type = "image"}, 
     {Image = "http://www.roblox.com/asset/?id=4483345998", ImageColor = Color3.fromRGB(255, 84, 84)} 
 )
 wait(0.2)
 Notification:Notify( 
     {Title = "猫王", Description = "支持作者猫王和小天"}, 
     {OutlineColor = Color3.fromRGB(80, 80, 80),Time = 10, Type = "image"}, 
     {Image = "http://www.roblox.com/asset/?id=4483345998", ImageColor = Color3.fromRGB(255, 84, 84)} 
 )
 wait(0.4)
 
local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextButton = Instance.new("TextButton")
local UITextSizeConstraint = Instance.new("UITextSizeConstraint")
local UICorner = Instance.new("UICorner")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.ResetOnSpawn = false

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(26, 26, 26)
Frame.BackgroundTransparency = 0.500
Frame.Position = UDim2.new(0.858712733, 0, 0.0237762257, 0)
Frame.Size = UDim2.new(0.129513338, 0, 0.227972031, 0)

TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton.BackgroundTransparency = 1.000
TextButton.Size = UDim2.new(1, 0, 1, 0)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "关闭"
TextButton.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton.TextScaled = true
TextButton.TextSize = 50.000
TextButton.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
TextButton.TextStrokeTransparency = 0.000
TextButton.TextWrapped = true
TextButton.MouseButton1Down:Connect(function()
    if TextButton.Text == "关闭" then
        TextButton.Text = "打开"
    else
        TextButton.Text = "关闭"
    end
    game:GetService("VirtualInputManager"):SendKeyEvent(true, "E" , false , game)
end) -- replace "E" with your keybind

UITextSizeConstraint.Parent = TextButton
UITextSizeConstraint.MaxTextSize = 30

local lib = loadstring(game:HttpGet"https://pastebin.com/raw/aDQ86WZA")()

local win = lib:Window("水下公司",Color3.fromRGB(0, 255, 0), Enum.KeyCode.E) -- your own keybind 

local tab = win:Tab("主要功能")

tab:Button("自动拾取物品", function()
local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoidRootPart = character:WaitForChild("HumanoidRootPart")
local startPosition = Vector3.new(-503.2907409667969, -43.40001678466797, -1464.4521484375)
local dropPosition = Vector3.new(-503.2907409667969, -43.40001678466797, -1464.4521484375)  
local distanceThreshold = 200

getgenv().RunScript = true

local function isNearStartingPosition(position)
    local distance = (position - startPosition).magnitude
    return distance <= distanceThreshold
end

local function fireProximityPromptByName(promptName)
    for _, descendant in ipairs(workspace:GetDescendants()) do
        if descendant:IsA("ProximityPrompt") and descendant.Name == promptName then
            fireproximityprompt(descendant)
        end
    end
end

local function interactWithProximityPrompt(item, promptName)
    local primaryPart = item.PrimaryPart or item:FindFirstChild("PrimaryPart")

    if primaryPart and not isNearStartingPosition(primaryPart.Position) then
        for teleportCount = 1, 4 do
            humanoidRootPart.CFrame = CFrame.new(primaryPart.Position + Vector3.new(0, 1, 0))
            wait(0.5)
            
            if item.Parent then
                fireProximityPromptByName(promptName)
                wait(0.5)
            else
                break 
            end
        end

        -- Move to the drop position after interacting with each item
        humanoidRootPart.CFrame = CFrame.new(dropPosition)
        wait(0.5)  
        game:GetService("ReplicatedStorage"):WaitForChild("Drop"):FireServer()
        wait(0.5)  
    end
end

while getgenv().RunScript do
    local itemsFolder = workspace:FindFirstChild("Items")

    if itemsFolder and #itemsFolder:GetChildren() > 1 then
        local initialItemCount = #itemsFolder:GetChildren()
        local collectedItemCount = 0

        while getgenv().RunScript and collectedItemCount < initialItemCount do
            local currentItemCount = #itemsFolder:GetChildren()

            if currentItemCount > 1 then
                for _, item in ipairs(itemsFolder:GetChildren()) do
                    interactWithProximityPrompt(item, "Prompt")
                    collectedItemCount = collectedItemCount + 1
                end
            else
                warn("No items left in the 'Items' folder. Stopping the script.")
                getgenv().RunScript = false
                break  
            end

            wait(0.5)  -- Add a delay before checking for items again
        end
    else
        warn("No or not enough items in the 'Items' folder. Stopping the script.")
        getgenv().RunScript = false
        break  
    end
end
end)